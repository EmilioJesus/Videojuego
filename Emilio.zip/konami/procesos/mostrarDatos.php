<?php 
	require_once "../clases/Crud.php";
	$crud = new Crud();
	echo $crud->mostrar();
 ?>